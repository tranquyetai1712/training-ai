# Antigravity `/schedule` Cheat Sheet: 30 Kịch Bản Tự Động Hóa Thực Chiến

Tài liệu quà tặng độc quyền dành cho người xem livestream. Tổng hợp 30 câu lệnh mẫu copy-paste ngay, hỗ trợ cả ngôn ngữ tự nhiên và biểu thức Cron chuẩn 5 trường.

---

## Mục Lục
- [Nhóm 1: Dân Văn Phòng, Hành Chính, Kế Toán & Nhân Sự (Ví dụ 1 - 8)](#nhom-1)
- [Nhóm 2: Học Tập, Ôn Thi & Nghiên Cứu (Ví dụ 9 - 16)](#nhom-2)
- [Nhóm 3: Marketing, Bán Hàng & Chăm Sóc Khách Hàng (Ví dụ 17 - 23)](#nhom-3)
- [Nhóm 4: Năng Suất Cá Nhân, Freelancer & Quản Lý Dự Án (Ví dụ 24 - 30)](#nhom-4)
- [Bảng Quy Đổi Cú Pháp Tự Nhiên & Cron 5 Trường](#bang-quy-doi)

---

<a name="nhom-1"></a>
## Nhóm 1: Dân Văn Phòng, Hành Chính, Kế Toán & Nhân Sự

### Ví dụ 1: Tóm tắt Email quan trọng đầu ngày làm việc
- **Mô tả:** Tự động lọc các email chưa đọc từ cấp trên hoặc khách hàng lúc bắt đầu giờ làm.
- **Lệnh tự nhiên:**
```bash
/schedule every weekday at 08:30 "Quét các email mới chưa đọc trong Gmail, lọc ra các email từ sếp và khách hàng quan trọng, tóm tắt 3 đầu việc khẩn cấp nhất"
```
- **Cron tương đương:** `30 8 * * 1-5`
- **Công cụ phối hợp:** `gmail:search_emails`, `gmail:read_email`.

### Ví dụ 2: Nhắc nhở và tóm tắt tài liệu trước cuộc họp 15 phút
- **Mô tả:** Đọc Google Calendar, tìm cuộc họp tiếp theo, đọc tài liệu đính kèm và tóm tắt nhanh.
- **Lệnh tự nhiên:**
```bash
/schedule in 45 minutes "Kiểm tra Google Calendar xem cuộc họp lúc 14:00 nội dung là gì, đọc file tài liệu đính kèm và tóm tắt nhanh 3 ý chính để tôi nắm trước khi vào họp"
```
- **Loại lịch:** One-shot timer.
- **Công cụ phối hợp:** `google_workspace:getCalendarEvents`, `read_file`.

### Ví dụ 3: Nhắc nộp báo cáo tuần vào chiều Thứ 6
- **Mô tả:** Kiểm tra thư mục Drive xem ai chưa nộp báo cáo và soạn tin nhắc nhở qua Slack.
- **Lệnh tự nhiên:**
```bash
/schedule every Friday at 16:00 "Kiểm tra thư mục Google Drive 'Bao_cao_tuan', xem phòng ban nào chưa nộp file và soạn sẵn bản nháp thông báo nhắc nhở lên kênh Slack chung"
```
- **Cron tương đương:** `0 16 * * 5`
- **Công cụ phối hợp:** `google_workspace:listFolder`, `slack:slack_post_message`.

### Ví dụ 4: Theo dõi nhân sự sắp hết hạn thử việc / hợp đồng lao động
- **Mô tả:** Quét file Excel nhân sự mỗi sáng thứ Hai, lọc người sắp đến hạn hợp đồng.
- **Lệnh tự nhiên:**
```bash
/schedule every Monday at 09:00 "Mở file danh_sach_hop_dong.xlsx, tìm những nhân sự có ngày hết hạn thử việc hoặc hợp đồng trong vòng 7 ngày tới, lập bảng tóm tắt và soạn email gửi HR Manager"
```
- **Cron tương đương:** `0 9 * * 1`
- **Công cụ phối hợp:** Python OpenPyXL, Gmail draft.

### Ví dụ 5: Nhắc chốt order cơm trưa cho phòng ban
- **Mô tả:** Đăng bình chọn quán ăn lên Slack lúc 10h45 sáng mỗi ngày làm việc.
- **Lệnh tự nhiên:**
```bash
/schedule every weekday at 10:45 "Đăng tin nhắn bình chọn quán ăn trưa hôm nay vào kênh #lunch trên Slack và nhắc mọi người chốt trước 11:15"
```
- **Cron tương đương:** `45 10 * * 1-5`
- **Công cụ phối hợp:** `slack:slack_post_message`.

### Ví dụ 6: Tổng hợp hóa đơn điện tử cuối tuần gửi kế toán
- **Mô tả:** Tự động lọc các email đính kèm hóa đơn VAT gửi về trong tuần và lập bảng kê.
- **Lệnh tự nhiên:**
```bash
/schedule every Friday at 17:00 "Tìm trong Gmail các email có file hóa đơn VAT gửi về trong tuần, tải PDF về thư mục 'Hoa_don_tuan' trên máy và thống kê tổng tiền ra file Excel"
```
- **Cron tương đương:** `0 17 * * 5`
- **Công cụ phối hợp:** `gmail:search_emails`, `gmail:download_attachment`.

### Ví dụ 7: Cảnh báo công nợ và gửi email nhắc thanh toán cuối tháng
- **Mô tả:** Kiểm tra danh sách công nợ khách hàng vào ngày 28 hàng tháng, soạn email lịch sự.
- **Lệnh tự nhiên:**
```bash
/schedule on the 28th of every month at 09:30 "Kiểm tra danh sách công nợ khách hàng, tạo danh sách các đơn vị quá hạn và soạn sẵn email lịch sự nhắc thanh toán"
```
- **Cron tương đương:** `30 9 28 * *`
- **Công cụ phối hợp:** `google_workspace:getGoogleSheetContent`, `gmail:draft_email`.

### Ví dụ 8: Tự động quét dọn và sắp xếp thư mục `Downloads`
- **Mô tả:** Gom và phân loại các file cũ hơn 7 ngày trong Downloads vào từng thư mục chuyên biệt.
- **Lệnh tự nhiên:**
```bash
/schedule every Sunday at 21:00 "Quét thư mục Downloads trên máy tính, gom các file đã tải quá 7 ngày vào các thư mục phân loại: Ảnh, Tài liệu PDF, Bộ cài đặt, File nén"
```
- **Cron tương đương:** `0 21 * * 0`
- **Công cụ phối hợp:** Shell / OS File Manager.

---

<a name="nhom-2"></a>
## Nhóm 2: Học Tập, Ôn Thi & Nghiên Cứu

### Ví dụ 9: Trợ lý Pomodoro ngắt quãng (Active Recall)
- **Mô tả:** Hẹn 25 phút học tập, sau đó AI nhắc nghỉ và kiểm tra nhanh bài học.
- **Lệnh tự nhiên:**
```bash
/schedule in 25 minutes "Nhắc tôi đứng dậy uống nước, hỏi tôi vừa học được khái niệm cốt lõi nào và ghi câu trả lời vào sổ tay 'learn_log.md'"
```
- **Loại lịch:** One-shot timer (hoặc lặp lại sau mỗi phiên).
- **Công cụ phối hợp:** `write_file`.

### Ví dụ 10: Luyện từ vựng theo phương pháp Lặp lại ngắt quãng (Spaced Repetition)
- **Mô tả:** Định kỳ vào các khung giờ nghỉ ngơi, AI tự bốc từ vựng và đặt câu hỏi trắc nghiệm.
- **Lệnh tự nhiên:**
```bash
/schedule every day at 12:00, 18:00, 21:00 "Lấy ngẫu nhiên 1 từ vựng trong file tu_vung_ielts.txt, tạo 1 câu hỏi đố trắc nghiệm 4 đáp án ngữ cảnh văn phòng để tôi ôn tập"
```
- **Cron tương đương:** `0 12,18,21 * * *`
- **Công cụ phối hợp:** `read_file`.

### Ví dụ 11: Canh điểm thi / Thông báo mới trên cổng thông tin trường học
- **Mô tả:** Tự động gửi request kiểm tra cổng đào tạo mỗi 2 tiếng để báo điểm thi.
- **Lệnh tự nhiên:**
```bash
/schedule every 2 hours "Truy cập trang cổng đào tạo sinh viên, kiểm tra xem đã có điểm thi môn Kinh tế vi mô chưa, nếu có thông báo ngay"
```
- **Cron tương đương:** `0 */2 * * *`
- **Công cụ phối hợp:** Browser subagent / Web fetching.

### Ví dụ 12: Cảnh báo Deadline bài tập trong vòng 48 giờ
- **Mô tả:** Quét lịch và bảng Trello mỗi sáng sớm để nhắc bài tập sắp đến hạn nộp.
- **Lệnh tự nhiên:**
```bash
/schedule every morning at 07:30 "Đọc danh sách bài tập trên Trello/Calendar, cảnh báo những bài tập có deadline trong vòng 48h tới kèm độ ưu tiên"
```
- **Cron tương đương:** `30 7 * * *`
- **Công cụ phối hợp:** `trello_trello:trelloReadBoard`, `google_workspace:getCalendarEvents`.

### Ví dụ 13: Theo dõi bài báo khoa học mới trên arXiv / Google Scholar
- **Mô tả:** Cập nhật các nghiên cứu mới về chủ đề AI mỗi sáng thứ Hai.
- **Lệnh tự nhiên:**
```bash
/schedule every Monday at 08:00 "Tìm kiếm các nghiên cứu mới xuất bản về chủ đề 'Agentic AI Workflows' trên arXiv, tóm tắt abstract 3 bài nổi bật nhất vào file Research.md"
```
- **Cron tương đương:** `0 8 * * 1`
- **Công cụ phối hợp:** `search_web`, `write_file`.

### Ví dụ 14: Hẹn giờ ôn tập bài cũ theo đường cong quên lãng Ebbinghaus
- **Mô tả:** Đặt hẹn tự động sau 3 ngày kể từ buổi học để củng cố trí nhớ dài hạn.
- **Lệnh tự nhiên:**
```bash
/schedule in 3 days "Nhắc tôi ôn lại sơ đồ tư duy môn Giải tích đã học hôm nay, tạo sẵn 5 câu hỏi trắc nghiệm kiểm tra nhanh"
```
- **Loại lịch:** One-shot timer (3 ngày = 259200 giây).
- **Công cụ phối hợp:** AI reasoning, chat prompt.

### Ví dụ 15: Tự động đóng phiên học và sao lưu tài liệu (Auto Git Backup)
- **Mô tả:** Hẹn giờ đi ngủ và tự động commit các ghi chú học tập lên GitHub.
- **Lệnh tự nhiên:**
```bash
/schedule at 23:00 "Nhắc tôi dừng học đi ngủ, tự động lưu toàn bộ các ghi chú trong ngày và tạo commit đẩy lên GitHub"
```
- **Cron tương đương:** `0 23 * * *`
- **Công cụ phối hợp:** `run_command` (git add, git commit).

### Ví dụ 16: Tóm tắt các bản tin công nghệ học thuật cuối tuần
- **Mô tả:** Đọc các blog khoa học kỹ thuật và tổng hợp thành 1 trang A4 mỗi sáng Chủ nhật.
- **Lệnh tự nhiên:**
```bash
/schedule every Sunday at 09:00 "Đọc các bài viết mới tuần qua từ 3 blog công nghệ chỉ định, tổng hợp các điểm tin chính thành 1 trang A4 Markdown"
```
- **Cron tương đương:** `0 9 * * 0`
- **Công cụ phối hợp:** `search_web`, `read_file`.

---

<a name="nhom-3"></a>
## Nhóm 3: Marketing, Bán Hàng & Chăm Sóc Khách Hàng

### Ví dụ 17: Theo dõi biến động giá của đối thủ cạnh tranh
- **Mô tả:** Quét giá sản phẩm trên sàn TMĐT mỗi 4 giờ, cảnh báo nếu đối thủ giảm giá.
- **Lệnh tự nhiên:**
```bash
/schedule every 4 hours "Vào link sản phẩm của đối thủ X trên sàn thương mại điện tử, ghi nhận giá và số lượng tồn kho vào Google Sheet, cảnh báo nếu giá giảm hơn 10%"
```
- **Cron tương đương:** `0 */4 * * *`
- **Công cụ phối hợp:** Browser subagent, `google_workspace:updateGoogleSheet`.

### Ví dụ 18: Theo dõi phản hồi & thương hiệu trên mạng xã hội (Social Listening)
- **Mô tả:** Tìm kiếm thảo luận về thương hiệu vào giữa chiều mỗi ngày làm việc.
- **Lệnh tự nhiên:**
```bash
/schedule every weekday at 15:00 "Tìm kiếm các bài đăng hoặc thảo luận mới nhất có từ khóa [Tên sản phẩm] trong ngày, phân tích cảm xúc khách hàng (khen/chê)"
```
- **Cron tương đương:** `0 15 * * 1-5`
- **Công cụ phối hợp:** `search_web`.

### Ví dụ 19: Tự động nhắc nhở Follow-up khách hàng tiềm năng
- **Mô tả:** Đặt hẹn 2 ngày sau khi gửi báo giá để kiểm tra và gợi ý thư nhắc khéo léo.
- **Lệnh tự nhiên:**
```bash
/schedule in 2 days "Kiểm tra xem khách hàng [Nguyen Van A] đã trả lời email báo giá chưa. Nếu chưa có phản hồi, gợi ý cho tôi 1 mẫu email follow-up khéo léo"
```
- **Loại lịch:** One-shot timer (48 giờ).
- **Công cụ phối hợp:** `gmail:search_emails`.

### Ví dụ 20: Gợi ý & soạn trước bài đăng định kỳ cho Fanpage / LinkedIn
- **Mô tả:** Soạn sẵn bài viết chuyên môn định kỳ vào thứ 3 và thứ 5 hàng tuần.
- **Lệnh tự nhiên:**
```bash
/schedule every Tuesday and Thursday at 09:00 "Lấy 1 ý tưởng trong bảng kế hoạch content, viết bản nháp bài chia sẻ chuyên môn cho LinkedIn và lưu vào thư mục drafts/"
```
- **Cron tương đương:** `0 9 * * 2,4`
- **Công cụ phối hợp:** `write_file`.

### Ví dụ 21: Thống kê số lượng Lead / Form đăng ký cuối ngày
- **Mô tả:** Đếm số lượng khách đăng ký từ Google Sheet vào 21h tối hàng ngày.
- **Lệnh tự nhiên:**
```bash
/schedule every day at 21:00 "Kiểm tra Google Form đăng ký khóa học hôm nay, đếm số lượng người mới đăng ký và báo cáo số liệu tổng kết qua tin nhắn"
```
- **Cron tương đương:** `0 21 * * *`
- **Công cụ phối hợp:** `google_workspace:getGoogleSheetContent`.

### Ví dụ 22: Nhắc chúc mừng sinh nhật khách hàng VIP
- **Mô tả:** Tra cứu danh sách CRM mỗi sáng sớm, soạn sẵn lời chúc cá nhân hóa.
- **Lệnh tự nhiên:**
```bash
/schedule every morning at 08:00 "Tra cứu danh sách khách hàng xem hôm nay có sinh nhật của ai không, soạn sẵn tin nhắn chúc mừng cá nhân hóa"
```
- **Cron tương đương:** `0 8 * * *`
- **Công cụ phối hợp:** `google_workspace:getGoogleSheetContent`.

### Ví dụ 23: Kiểm tra thứ hạng từ khóa SEO định kỳ
- **Mô tả:** Kiểm tra vị trí top từ khóa mục tiêu vào sáng thứ Hai đầu tuần.
- **Lệnh tự nhiên:**
```bash
/schedule every Monday at 07:00 "Tìm kiếm vị trí thứ hạng của 5 từ khóa SEO chiến lược trên Google Search, so sánh với thứ hạng tuần trước và cập nhật báo cáo"
```
- **Cron tương đương:** `0 7 * * 1`
- **Công cụ phối hợp:** `search_web`.

---

<a name="nhom-4"></a>
## Nhóm 4: Năng Suất Cá Nhân, Freelancer & Quản Lý Dự Án

### Ví dụ 24: Rà soát Task bị tắc nghẽn (Blocker) trước giờ Daily Standup
- **Mô tả:** Quét bảng Jira/Trello trước 15 phút giờ họp sáng để tìm task bị nghẽn.
- **Lệnh tự nhiên:**
```bash
/schedule every weekday at 09:15 "Đọc bảng Trello/Jira của dự án, liệt kê các task đang ở cột 'In Progress' quá 3 ngày hoặc chưa có người phụ trách để chuẩn bị họp lúc 09:30"
```
- **Cron tương đương:** `15 9 * * 1-5`
- **Công cụ phối hợp:** `jira:jira_get`, `trello_trello:trelloReadBoard`.

### Ví dụ 25: Chờ tiến trình nền dài (Render video, xuất file lớn, train model, CI build)
- **Mô tả:** Hẹn giờ kiểm tra tiến trình nền mà không cần ngồi canh mắt nhìn màn hình.
- **Lệnh tự nhiên:**
```bash
/schedule in 20 minutes "Kiểm tra xem tiến trình export video / build code đã hoàn thành chưa, nếu xong thì báo cho tôi biết kết quả và dung lượng file"
```
- **Loại lịch:** One-shot timer.
- **Công cụ phối hợp:** `run_command` (ps, ls).

### Ví dụ 26: Phản tư cuối ngày (Daily Evening Review)
- **Mô tả:** Gợi nhắc 3 câu hỏi đánh giá hiệu suất cá nhân lúc 17h30 chiều.
- **Lệnh tự nhiên:**
```bash
/schedule every day at 17:30 "Gửi cho tôi 3 câu hỏi đánh giá ngày: 1. Việc quan trọng nhất đã làm xong? 2. Điều gì làm mất thời gian? 3. Ba ưu tiên cho ngày mai? Lưu lại vào nhật ký"
```
- **Cron tương đương:** `30 17 * * *`
- **Công cụ phối hợp:** `write_file`.

### Ví dụ 27: Nhắc vận động, bảo vệ mắt và cột sống (Ergonomics Reminder)
- **Mô tả:** Lời nhắc thư giãn cơ bắp sau mỗi 60 phút làm việc liên tục.
- **Lệnh tự nhiên:**
```bash
/schedule every 60 minutes "Nhắc tôi đứng lên uống một cốc nước, nhìn ra xa 20 giây và làm 2 động tác xoay cổ vai gáy"
```
- **Cron tương đương:** `0 * * * *`
- **Công cụ phối hợp:** Notification / Chat alert.

### Ví dụ 28: Giám sát trạng thái hoạt động của Website cá nhân / Portfolio
- **Mô tả:** Tự động gửi HTTP request kiểm tra website mỗi 30 phút, cảnh báo nếu sập.
- **Lệnh tự nhiên:**
```bash
/schedule every 30 minutes "Gửi request kiểm tra trang web cá nhân xem có phản hồi HTTP 200 không, nếu có lỗi 500 hoặc timeout thì lập tức cảnh báo"
```
- **Cron tương đương:** `*/30 * * * *`
- **Công cụ phối hợp:** `run_command` (curl).

### Ví dụ 29: Cảnh báo kỳ gia hạn các gói dịch vụ thuê bao (Subscriptions)
- **Mô tả:** Kiểm tra các dịch vụ trực tuyến sắp đến hạn trừ tiền vào ngày mùng 1 hàng tháng.
- **Lệnh tự nhiên:**
```bash
/schedule on the 1st of every month at 09:00 "Kiểm tra danh sách các gói dịch vụ định kỳ (Hosting, Domain, Spotify, Netflix, ChatGPT...) xem tháng này dịch vụ nào đến hạn trừ tiền"
```
- **Cron tương đương:** `0 9 1 * *`
- **Công cụ phối hợp:** `read_file`.

### Ví dụ 30: Tổng kết tuần KPT (Keep - Problem - Try) và lên lịch tuần mới
- **Mô tả:** Tạo khung đánh giá tuần và lên danh sách mục tiêu vào tối Chủ nhật.
- **Lệnh tự nhiên:**
```bash
/schedule every Sunday at 20:00 "Đọc lại lịch trình tuần qua trên Calendar, tự động tạo khung báo cáo KPT và gợi ý danh sách mục tiêu cho tuần tới"
```
- **Cron tương đương:** `0 20 * * 0`
- **Công cụ phối hợp:** `google_workspace:getCalendarEvents`, `write_file`.

---

<a name="bang-quy-doi"></a>
## Bảng Quy Đổi Cú Pháp Tự Nhiên & Cron 5 Trường

| Ngôn ngữ tự nhiên | Biểu thức Cron chuẩn | Ý nghĩa chu kỳ |
|---|---|---|
| `every weekday at 9am` | `0 9 * * 1-5` | 09:00 sáng từ Thứ 2 đến Thứ 6 |
| `every 2 hours` | `0 */2 * * *` | Mỗi 2 tiếng vào đầu giờ |
| `every 30 minutes` | `*/30 * * * *` | Mỗi nửa tiếng một lần |
| `every Friday at 16:30` | `30 16 * * 5` | 16:30 chiều Thứ 6 hàng tuần |
| `on the 1st of every month at 08:00` | `0 8 1 * *` | 08:00 sáng ngày mùng 1 hàng tháng |
| `every Sunday at 20:00` | `0 20 * * 0` | 20:00 tối Chủ nhật hàng tuần |
| `in 15 minutes` | *One-shot Timer* | Chờ đúng 15 phút (900 giây) rồi chạy 1 lần duy nhất |
