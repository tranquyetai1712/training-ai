# Sổ Tay Kịch Bản Người Dẫn Livestream: Làm Chủ Lệnh `/schedule` Antigravity

- **Thời lượng phát sóng:** 60 phút
- **Chủ đề:** Tự động hóa công việc & học tập với lệnh `/schedule` trong Google Antigravity
- **Người thực hiện:** Host / Giảng viên

---

## I. CHECKLIST CHUẨN BỊ TRƯỚC GIỜ LÊN SÓNG (T-15 Phút)

- [ ] **Môi trường Workspace:**
  - Kiểm tra file `danh_sach_hop_dong.xlsx` đã có sẵn tại thư mục gốc.
  - Kiểm tra file `tu_vung_ielts.txt` đã có sẵn tại thư mục gốc.
  - Đảm bảo terminal đã mở sẵn trong workspace sạch sẽ, không có log nhạy cảm.
- [ ] **Công cụ Livestream:**
  - Font size terminal / IDE tăng lên mức 16px - 18px để khán giả xem trên điện thoại đọc rõ chữ.
  - Test âm thanh micrô và độ mượt chia sẻ màn hình.
  - Chuẩn bị sẵn link tải file `cheat-sheet-30-prompts.md` để gửi vào khung chat live ở cuối buổi.
- [ ] **Kịch bản dự phòng (Failsafe Backup):**
  - Mở sẵn 1 tab ghi chú chứa sẵn các câu prompt và kết quả mẫu đề phòng mạng lag.

---

## II. TIMELINE TỪNG PHÚT & LỜI THOẠI CHI TIẾT (00:00 – 60:00)

```
00:00 ─── Mở đầu & Hook ─── 04:00 ─── Khái niệm ─── 07:00 ─── HERO DEMO 1 ─── 12:00
12:00 ─── HERO DEMO 2 (Office) ─── 22:00 ─── HERO DEMO 3 (Study) ─── 35:00
35:00 ─── TASK MANAGER (/tasks) ─── 43:00 ─── Q&A / FAILSAFE ─── 50:00 ─── Quà tặng ─── 60:00
```

---

### PHẦN 1: MỞ ĐẦU & BẺ GÃY TƯ DUY CŨ (00:00 – 07:00)

#### 00:00 – 04:00: Hook & Chào hỏi
* **Hành động:** Bật webcam chính, chưa vội chia sẻ màn hình code.
* **Lời thoại người dẫn:**
  > *"Chào tất cả mọi người đã đến với buổi livestream hôm nay! Mình có một câu hỏi nhanh cho các bạn: Bao nhiêu bạn ở đây đang dùng ChatGPT, Gemini hay Claude theo kiểu: Gõ một câu hỏi $\rightarrow$ Ngồi dán mắt vào màn hình chờ AI gõ từng chữ $\rightarrow$ Copy kết quả rồi tắt tab?*
  >
  > *Nếu bạn đang dùng như vậy, bạn mới chỉ đang tận dụng 10% sức mạnh của kỷ nguyên AI Agent! Hôm nay, mình sẽ chỉ cho các bạn cách biến Google Antigravity thành một trợ lý tự giác: Bạn giao việc, hẹn giờ, và AI sẽ **tự động thức dậy làm việc ngầm** thay bạn, kể cả khi bạn đang bận họp hay đang ngủ!"*

#### 04:00 – 07:00: Điểm khác biệt cốt lõi của `/schedule`
* **Hành động:** Chuyển màn hình chia sẻ sang giao diện Antigravity.
* **Lời thoại người dẫn:**
  > *"Các bạn thường đặt báo thức trên điện thoại đúng không? Nhưng chuông reo thì nó chỉ kêu 'bíp bíp', bạn vẫn phải lóc cóc tự tay vào làm. Còn với lệnh `/schedule` trong Antigravity: Đến giờ hẹn, **AI không chỉ đánh thức bạn, mà nó tự động xắn tay áo vào làm dứt điểm tác vụ đó luôn**!*
  >
  > *Đặc biệt, nó hoạt động theo cơ chế **Non-blocking**. Nghĩa là sau khi bạn gõ lệnh hẹn giờ, AI không hề làm treo màn hình chat. Bạn vẫn tiếp tục chat, giao việc khác hoàn toàn bình thường."*

---

### PHẦN 2: TRÌNH DIỄN THỰC CHIẾN 3 HERO DEMO (07:00 – 35:00)

#### 07:00 – 12:00: HERO DEMO 1 (Hiệu Ứng Wow Sau 2 Phút)
* **Mục tiêu:** Tạo ấn tượng mạnh ngay lập tức về tính năng Non-blocking.
* **Thao tác màn hình:** Gõ câu lệnh hẹn 2 phút:
```bash
/schedule in 2 minutes "Kiểm tra xem trong thư mục hiện tại có file excel nào không và báo cáo số lượng dòng dữ liệu"
```
* **Khoảnh khắc ăn tiền (The Wow Moment):**
  * Trong lúc bộ đếm 2 phút đang chạy ngầm, bạn quay sang hỏi AI một câu hoàn toàn khác: *"Viết giúp tôi 1 bài thơ ngắn 4 câu về sự chăm chỉ của lập trình viên"*.
  * AI trả lời bài thơ ngay lập tức.
  * Đúng 2 phút sau: Màn hình tự động nhảy thông báo Agent thức dậy hoàn thành việc kiểm tra file Excel và in ra kết quả.
* **Talking point:**
  > *"Các bạn thấy chưa? Không hề có chuyện màn hình bị đơ hay quay tròn chờ đợi. AI xử lý đa nhiệm song song như một nhân viên thực thụ!"*

---

#### 12:00 – 22:00: HERO DEMO 2 (Ứng Dụng Văn Phòng: Quản Lý Hạn Hợp Đồng)
* **Nỗi đau:** Quản lý nhân sự, kế toán luôn phải nhớ mở file Excel mỗi tuần để lọc hợp đồng sắp hết hạn.
* **Thao tác màn hình:** Mở file `danh_sach_hop_dong.xlsx` cho khán giả xem lướt qua (6 nhân viên, 2 người sắp hết hạn).
* **Câu lệnh gõ:**
```bash
/schedule in 30 seconds "Đọc file danh_sach_hop_dong.xlsx, lọc ra những nhân sự có hợp đồng hết hạn trong 7 ngày tới, lập bảng tóm tắt và soạn mẫu email nhắc gia hạn"
```
*(Ghi chú với khán giả: Trong thực tế ta dùng `every Monday at 08:30`, nhưng ở buổi live ta đặt 30 giây để thấy kết quả ngay).*
* **Kết quả hiển thị:** AI xuất bảng Markdown 2 nhân viên (Nguyễn Văn An, Trần Thị Bích) kèm mẫu email lịch sự gửi sếp.
* **Talking point:**
  > *"Tưởng tượng sáng thứ Hai nào bạn mở máy ra, AI đã làm sẵn bảng này và soạn sẵn email, bạn chỉ cần bấm nút Send là xong. Tiết kiệm ít nhất 30 phút rà soát mỗi tuần!"*

---

#### 22:00 – 35:00: HERO DEMO 3 (Ứng Dụng Học Tập: Spaced Repetition Quiz)
* **Nỗi đau:** Học từ vựng, ôn thi chứng chỉ học trước quên sau, lười mở app flashcard.
* **Thao tác màn hình:** Mở file `tu_vung_ielts.txt`.
* **Câu lệnh gõ:**
```bash
/schedule in 20 seconds "Lấy ngẫu nhiên 1 từ trong file tu_vung_ielts.txt, tạo 1 câu hỏi trắc nghiệm 4 đáp án A, B, C, D ngữ cảnh công sở để tôi ôn tập"
```
* **Tương tác trực tiếp:**
  * AI đưa ra câu hỏi trắc nghiệm trên màn hình.
  * Bạn hô hào: *"Các bạn comment đáp án vào khung chat livestream giúp mình: A, B, C hay D?"*
  * Bạn chọn đáp án theo số đông khán giả và gõ trả lời $\rightarrow$ AI chấm điểm và giải thích ngữ pháp.
* **Talking point:**
  > *"Học ngoại ngữ thụ động nhưng đạt hiệu quả chủ động: AI tự tìm đến bạn để kiểm tra bài vào giờ nghỉ trưa!"*

---

### PHẦN 3: LÀM CHỦ TASK MANAGER & BÍ QUYẾT CRON (35:00 – 45:00)

#### 35:00 – 43:00: Bảng Quản Trị Tác Vụ TASK MANAGER
* **Thao tác màn hình:** Gõ `/tasks`.
* **Giải thích các trạng thái:**
  * `Pending` / `Active`: Lịch đang chờ kích hoạt.
  * `Completed`: Đã kích hoạt xong.
* **Thực hành thao tác nóng:**
  * Nhấn phím `k` (Kill) để hủy một lịch hẹn không còn cần thiết.
  * Nhấn phím `x` (Prune) để xóa sạch các tác vụ đã hoàn thành.
* **Bí quyết viết Cron tự nhiên:**
  * Không cần thuộc công thức `0 9 * * 1-5`.
  * Cứ gõ tiếng Anh hoặc tiếng Việt tự nhiên: `every weekday at 9am`, `every 2 hours`, `on the 1st of every month at 8am`.

---

### PHẦN 4: HỎI ĐÁP, FAILSAFE & QUÀ TẶNG (45:00 – 60:00)

#### 45:00 – 50:00: Bảng Xử Lý Sự Cố Trực Tiếp (FAILSAFE Checklist)
* **Câu hỏi 1: "Tắt máy tính hoặc tắt app Antigravity thì lịch có chạy không?"**
  * *Trả lời:* `/schedule` chạy trong phạm vi phiên làm việc (Conversation-scoped). Nếu tắt app, lịch sẽ dừng. Nếu muốn chạy vĩnh viễn 24/7 trên server kể cả khi tắt máy, hãy dùng lệnh `/automation` hoặc cấu hình Sidecar.
* **Câu hỏi 2: "Có bị tốn token liên tục trong lúc đang đếm ngược không?"**
  * *Trả lời:* Hoàn toàn KHÔNG! Lúc đếm ngược hệ thống dùng timer của hệ điều hành, tiêu tốn 0 token. Chỉ khi chuông reo và AI bắt đầu phân tích dữ liệu thì mới bắt đầu tính token.
* **Nếu demo bị lỗi mạng:**
  * Bình tĩnh mở file backup `docs/schedule-livestream/cheat-sheet-30-prompts.md` ra giải thích cấu trúc lệnh cho khán giả.

#### 50:00 – 60:00: Tổng kết & Tặng Cheat Sheet 30 Prompt
* **Tóm tắt 3 bước cốt lõi:**
  1. *Tìm việc lặp lại hoặc việc cần chờ đợi.*
  2. *Thiết lập với cú pháp `/schedule`.*
  3. *Kiểm soát qua bảng điều khiển `/tasks`.*
* **Kêu gọi hành động (Call to Action):**
  * Gửi link tải file Cheat Sheet 30 Prompt mẫu cho khán giả.
  * Nhắc khán giả bấm Like, Subscribe kênh và để lại comment về ý tưởng tự động hóa mà họ muốn thực hiện.
